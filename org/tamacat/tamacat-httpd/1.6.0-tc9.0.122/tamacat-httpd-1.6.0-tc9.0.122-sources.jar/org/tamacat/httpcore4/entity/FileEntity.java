/*
 * ====================================================================
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 *
 */

package org.tamacat.httpcore4.entity;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.tamacat.httpcore4.util.Args;

/**
 * A self contained, repeatable entity that obtains its content from a file.
 *
 * @since 4.0
 */
public class FileEntity extends AbstractHttpEntity implements Cloneable {

    protected final File file;

    /**
     * Creates a new instance.
     *
     * @param file The file to serve.
     * @param contentType  The content type for the given {@code file}.
     *
     * @deprecated (4.1.3) {@link #FileEntity(File, ContentType)}
     */
    @Deprecated
    public FileEntity(final File file, final String contentType) {
        super();
        this.file = Args.notNull(file, "File");
        setContentType(contentType);
    }

    /**
     * Creates a new instance.
     *
     * @param file The file to serve.
     * @param contentType  The content type for the given {@code file}.
     *
     * @since 4.2
     */
    public FileEntity(final File file, final ContentType contentType) {
        super();
        this.file = Args.notNull(file, "File");
        if (contentType != null) {
            setContentType(contentType.toString());
        }
    }

    /**
     * Creates a new instance.
     *
     * @param file The file to serve.
     *
     * @since 4.2
     */
    public FileEntity(final File file) {
        super();
        this.file = Args.notNull(file, "File");
    }

    @Override
    public boolean isRepeatable() {
        return true;
    }

    @Override
    public long getContentLength() {
        return this.file.length();
    }

    @Override
    public InputStream getContent() throws IOException {
        return new FileInputStream(this.file);
    }

    @Override
    public void writeTo(final OutputStream outStream) throws IOException {
        Args.notNull(outStream, "Output stream");
        final InputStream inStream = new FileInputStream(this.file);
        try {
            final byte[] tmp = new byte[OUTPUT_BUFFER_SIZE];
            int l;
            while ((l = inStream.read(tmp)) != -1) {
                outStream.write(tmp, 0, l);
            }
            outStream.flush();
        } finally {
            inStream.close();
        }
    }

    /**
     * Tells that this entity is not streaming.
     *
     * @return {@code false}
     */
    @Override
    public boolean isStreaming() {
        return false;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        // File instance is considered immutable
        // No need to make a copy of it
        return super.clone();
    }

} // class FileEntity
