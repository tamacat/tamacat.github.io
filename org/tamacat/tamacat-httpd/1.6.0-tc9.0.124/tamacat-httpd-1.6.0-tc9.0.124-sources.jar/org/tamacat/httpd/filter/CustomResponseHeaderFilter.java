/*
 * Copyright 2019 tamacat.org
 * Licensed under the Apache License, Version 2.0
 * http://www.apache.org/licenses/LICENSE-2.0
 */
package org.tamacat.httpd.filter;

import java.util.HashSet;
import java.util.LinkedHashMap;

import org.tamacat.httpcore4.HttpRequest;
import org.tamacat.httpcore4.HttpResponse;
import org.tamacat.httpcore4.protocol.HttpContext;
import org.tamacat.httpd.config.ServiceUrl;

/**
 * The response filter of append or remove response header.
 */
public class CustomResponseHeaderFilter implements ResponseFilter {
	
	ServiceUrl serviceUrl;
	LinkedHashMap<String, String> appendHeaders = new LinkedHashMap<>();
	HashSet<String> removeHeaders = new HashSet<>();
	
	@Override
	public void init(ServiceUrl serviceUrl) {
		this.serviceUrl = serviceUrl;
	}

	@Override
	public void afterResponse(HttpRequest request, HttpResponse response,
			HttpContext context) {
		for (String name : appendHeaders.keySet()) {
			response.addHeader(name, appendHeaders.get(name));
		}
		for (String name : removeHeaders.toArray(new String[removeHeaders.size()])) {
			response.removeHeaders(name);
		}
	}
	
	/**
	 * Append the response header.
	 * @param name
	 * @param value
	 */
	public void setAppendHeader(String name, String value) {
		appendHeaders.put(name, value);
	}
	
	/**
	 * Remove the response header.
	 * @param name
	 */
	public void setRemoveHeader(String name) {
		removeHeaders.add(name);
	}
}
