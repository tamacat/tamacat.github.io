/*
 * Copyright (c) 2013 tamacat.org
 * All rights reserved.
 */
package org.tamacat.httpd.core;

import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.hc.core5.http.ClassicHttpRequest;
import org.apache.hc.core5.http.HttpRequestFactory;
//core5 also has an impl.nio.DefaultHttpRequestFactory; the classic (blocking) counterpart
//of 4.4's impl.DefaultHttpRequestFactory is impl.io.DefaultClassicHttpRequestFactory (R-5.3).
import org.apache.hc.core5.http.impl.io.DefaultClassicHttpRequestFactory;
import org.apache.hc.core5.http.impl.io.HttpService;
import org.tamacat.httpd.config.ServerConfig;
import org.tamacat.httpd.util.DefaultThreadFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>The factory class of {@link ExecutorService}.
 *  Support {@link Executors#newFixedThreadPool} or {@link Executors#newCachedThreadPool}.
 * @since 1.1
 */
public class DefaultWorkerExecutor implements WorkerExecutor {
	private static final Logger LOG = LoggerFactory.getLogger(DefaultWorkerExecutor.class);

	protected ServerConfig serverConfig;
	protected HttpService httpService;

	protected int maxThreads;

	protected ExecutorService executorService;
	protected DefaultThreadFactory threadFactory = new DefaultThreadFactory();
	protected HttpRequestFactory<ClassicHttpRequest> httpRequestFactory;
	
	public DefaultWorkerExecutor() {
		this(DefaultClassicHttpRequestFactory.INSTANCE);
	}

	protected DefaultWorkerExecutor(HttpRequestFactory<ClassicHttpRequest> httpRequestFactory) {
		this.httpRequestFactory = httpRequestFactory;
	}

	public void setHttpRequestFactory(HttpRequestFactory<ClassicHttpRequest> httpRequestFactory) {
		this.httpRequestFactory = httpRequestFactory;
	}

	public void execute(Socket socket) throws IOException {
		ExecutorService executors = getExecutorService();
		executors.execute(createWorker(socket));
	}

	protected Worker createWorker(Socket socket) {
		return new DefaultWorker(serverConfig, httpService, httpRequestFactory, socket);
	}

	@Override
	public void setServerConfig(ServerConfig serverConfig) {
		this.serverConfig = serverConfig;
		//set the maximun worker threads.
		maxThreads = serverConfig.getMaxThreads();
		LOG.info(serverConfig.getParam("ServerName")+":"+serverConfig.getPort() + " MaxServerThreads: " + maxThreads);
		String name = serverConfig.getParam("WorkerThreadName", "httpd");
		threadFactory.setName(name);
	}

	@Override
	public void setHttpService(HttpService httpService) {
		this.httpService = httpService;
	}

	/**
	 * <p>returns a fixed thread pool or cached thread pool.
	 * If fixed number of maximum threads, It use the fixed thread pool
	 * of {@code ExecutorService}.
	 * @return {@link ThreadPoolExecutor}
	 */
	protected ExecutorService getExecutorService() {
		if (executorService == null) {
			if (maxThreads > 0) {
				executorService = Executors.newFixedThreadPool(maxThreads, threadFactory);
			} else {
				executorService = Executors.newCachedThreadPool(threadFactory);
			}
		}
		return executorService;
	}

	@Override
	public void shutdown() {
		if (executorService != null) {
			executorService.shutdown();
		}
	}
}
