/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.apache.coyote.http11;

import java.io.Serial;

/**
 * Exception used to mark the specific error condition of the HTTP headers exceeding the maximum permitted size.
 */
public class HeadersTooLargeException extends IllegalStateException {

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Construct an exception with no detail message.
     */
    public HeadersTooLargeException() {
        super();
    }

    /**
     * Construct an exception with the specified detail message and cause.
     *
     * @param message The detail message
     * @param cause   The cause
     */
    public HeadersTooLargeException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Construct an exception with the specified detail message.
     *
     * @param message The detail message
     */
    public HeadersTooLargeException(String message) {
        super(message);
    }

    /**
     * Construct an exception with the specified cause.
     *
     * @param cause The cause
     */
    public HeadersTooLargeException(Throwable cause) {
        super(cause);
    }
}
